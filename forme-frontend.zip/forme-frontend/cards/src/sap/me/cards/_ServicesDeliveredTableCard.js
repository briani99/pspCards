sap.ui.define([
    "jquery.sap.global",
    "sap/ui/core/XMLComposite",
    "sap/me/cards/Card",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/Router",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/Sorter"
], function(jQuery, XMLComposite, Card, JSONModel, Router, Filter, FilterOperator, Sorter) {
    "use strict";

    var _ServicesDeliveredTableCard = XMLComposite.extend("sap.me.cards._ServicesDeliveredTableCard", {
        metadata: {
            properties: {
                growing: {type: "boolean", defaultValue: false, group: "Designtime"},
                growingThreshold: {type: "int", defaultValue: 10, group: "Designtime"}
            }
        }
    });

    _ServicesDeliveredTableCard.prototype.init = function() {
        XMLComposite.prototype.init.apply(this, arguments);

        Card.setBusy(this, true);
    };

    _ServicesDeliveredTableCard.prototype.applySettings = function() {
        XMLComposite.prototype.applySettings.apply(this, arguments);
        if (!this._bCardInitialized) {
            var oContent = this.getAggregation("_content"), oContext = this.data("context");

            oContent.setModel(this._oAuthModel = new JSONModel(), "$" + this.alias + ".auth");
            var oAuth = {};
            oAuth.systemStatusVisible = oContext.authorization.exists("INSTDISP") || oContext.authorization.exists("INSTPROD");
            oAuth.ordersVisible = oContext.authorization.exists("S4M_ORDERS") || oContext.authorization.exists("S4M_SWAGRM");

            this._oAuthModel.setData(oAuth);

            oContent.setModel(this._oODataModel = oContext.model, "$" + this.alias + ".odata");

            oContent.setModel(this._oProductTypeFilterModel = new JSONModel(), "$" + this.alias + ".ProductTypeFilter");
            this.setProductTypeFilterModel();
            this._bInitialProductCounter = true;

            oContent.setModel(this._oSorterDialogModel = new JSONModel(), "$" + this.alias + ".SorterDialog");

            this._bCardInitialized = true;
        }
    };

    _ServicesDeliveredTableCard.prototype.onAfterRendering = function() {
        this.i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.cards");
        this.setSorterDialog();
    };

    _ServicesDeliveredTableCard.prototype.onUpdateFinished = function(oEvent) {
        var tableGrowing = this.byId("servicesDeliveredTable");
        tableGrowing.setGrowingThreshold(this.getGrowingThreshold());
        tableGrowing.setGrowing(this.getGrowing());

        Card.setBusy(this, false);
    };

    _ServicesDeliveredTableCard.prototype.setProductTypeFilterModel = function() {
        var aProductTypeList = [
            {
                typeName: "On-Premise",
                productsCounter: this._onPremiseProductsCounter
            },
            {
                typeName: "Cloud",
                productsCounter: this._cloudProductsCounter
            }
        ];

        this._oProductTypeFilterModel.setData(aProductTypeList);
    };

    _ServicesDeliveredTableCard.prototype.setSorterDialog = function() {
        var aSorterData = [
            {
                bDescending: false,
                text: this.i18n.getText("products_sortAscending"),
                icon: "/images/ascending.svg",
                sortProperty: ""
            },
            {
                bDescending: true,
                text: this.i18n.getText("products_sortDescending"),
                icon: "/images/descending.svg",
                sortProperty: ""
            }
        ];

        this._oSorterDialogModel.setData(aSorterData);
    };

    _ServicesDeliveredTableCard.prototype.setSortProperty = function(sSortProperty) {
        var aSorterDialogData = this._oSorterDialogModel.getData();

        aSorterDialogData.forEach(function(oProperty) {
            oProperty.sortProperty = sSortProperty;
        });
    };

    _ServicesDeliveredTableCard.prototype.filterProductsByType = function(sSelectedKey) {
        this._bInitialProductCounter = false;
        var oServicesDeliveredTable = this.byId("servicesDeliveredTable"),
            oServicesDeliveredTableFilter;

        if (sSelectedKey) {
            oServicesDeliveredTableFilter = new Filter({
                filters: [
                    new Filter({
                        path: "typeName",
                        operator: FilterOperator.EQ,
                        value1: sSelectedKey
                    }),
                    new Filter({
                        path: "typeName",
                        operator: FilterOperator.EQ,
                        value1: "Hybrid"
                    })
                ],
                and: false

            });
        }

        oServicesDeliveredTable.getBinding("items").filter(oServicesDeliveredTableFilter);
    };

    _ServicesDeliveredTableCard.prototype.filterPortfolioCategories = function(sSelectedProductTypeKey) {
        var oPortfolioCategoriesComboBox = this.byId("productPortfolioCategorySelect");
        var oPortfolioCategoriesFilter = new Filter({
            filters: [
                new Filter({
                    path: "productType",
                    operator: FilterOperator.EQ,
                    value1: sSelectedProductTypeKey
                }),
                new Filter({
                    path: "productType",
                    operator: FilterOperator.EQ,
                    value1: "Hybrid"
                })
            ],
            and: false
        });

        oPortfolioCategoriesComboBox.getBinding("items").filter(oPortfolioCategoriesFilter);
    };

    _ServicesDeliveredTableCard.prototype.getSelectedProduct = function(oItem) {
        var oContext = oItem.getBindingContext("$" + this.alias + ".odata"),
            sPath = oContext.getPath(),
            oSelectedProduct = oContext.getObject(sPath);

        return oSelectedProduct;
    };

    _ServicesDeliveredTableCard.prototype.navigateToDetailPage = function(oEvent, sTab) {
        var oItem = oEvent.getSource(),
            sSelectedProductId = encodeURIComponent(this.getSelectedProduct(oItem).ID),
            oRouter = Router.getRouter("shellRouter");

        oRouter.navTo("productDetail", {
            productKey: sSelectedProductId,
            tab: sTab
        });
    };

    _ServicesDeliveredTableCard.prototype.navigateToProductDetailPage = function(oEvent) {
        this.navigateToDetailPage(oEvent, "overview");
    };

    _ServicesDeliveredTableCard.prototype.navigateToSystems = function(oEvent) {
        this.navigateToDetailPage(oEvent, "systems");
    };

    _ServicesDeliveredTableCard.prototype.navigateToEvents = function(oEvent) {
        this.navigateToDetailPage(oEvent, "events");
    };

    _ServicesDeliveredTableCard.prototype.navigateToOpenIncidents = function(oEvent) {
        this.navigateToDetailPage(oEvent, "openIncidents");
    };

    _ServicesDeliveredTableCard.prototype.navigateToLicenses = function(oEvent) {
        this.navigateToDetailPage(oEvent, "licenses");
    };

    _ServicesDeliveredTableCard.prototype.navigateToOrders = function(oEvent) {
        this.navigateToDetailPage(oEvent, "orders");
    };

    _ServicesDeliveredTableCard.prototype.onSort = function(oEvent) {
        var oSource = oEvent.getSource();

        this.byId("sorterDialog").openBy(oSource);
    };

    _ServicesDeliveredTableCard.prototype.handleSortDialogConfirm = function(oEvent) {
        var oTable = this.byId("servicesDeliveredTable"),
            oBinding = oTable.getBinding("items"),
            oSource = oEvent.getSource(),
            oContext = oSource.getBindingContext("$" + this.alias + ".SorterDialog"),
            bDescending = oContext.getProperty("bDescending"),
            sSortColumn = oContext.getProperty("sortProperty"),
            aSorters = [];

        aSorters.push(new Sorter(sSortColumn, bDescending));
        oBinding.sort(aSorters);

    };

    _ServicesDeliveredTableCard.prototype._isNumberGreaterThanZero = function(iNumber) {
        return iNumber > 0 ? true : false;
    };

    _ServicesDeliveredTableCard.prototype._formatPortfolioCategoryName = function(sKey, sText) {
        return sText || sKey;
    };

    _ServicesDeliveredTableCard.prototype._formatLicensesOverConsumption = function(iLicensesOverConsumption) {
        return iLicensesOverConsumption > 0 ? "sap-icon://message-warning" : "";
    };

    _ServicesDeliveredTableCard.prototype._formatLicensesOverConsumptionState = function(iLicensesOverConsumption) {
        return iLicensesOverConsumption > 0 ? "Warning" : "None";
    };

    _ServicesDeliveredTableCard.prototype._formatTenantsDisrupted = function(iTenantsDisrupted) {
        return iTenantsDisrupted > 0 ? "sap-icon://message-warning" : "";
    };

    _ServicesDeliveredTableCard.prototype._formatTenantsDisruptedState = function(iTenantsDisrupted) {
        return iTenantsDisrupted > 0 ? "Warning" : "None";
    };

    _ServicesDeliveredTableCard.prototype._formatIncidentsRequiringAttentionState = function(iLicensesOverConsumption) {
        return iLicensesOverConsumption > 0 ? "Error" : "None";
    };

    _ServicesDeliveredTableCard.prototype._formatIncidentsRequiringAttentionIcon = function(iLicensesOverConsumption) {
        return iLicensesOverConsumption > 0 ? "sap-icon://message-error" : "";
    };

    _ServicesDeliveredTableCard.prototype._formatVisibility = function(iLicensesOverConsumption) {
        return iLicensesOverConsumption > 0 ? true : false;
    };

    _ServicesDeliveredTableCard.prototype._formatLink = function(iVisibleCount, iTotalCount) {
        return iVisibleCount > 0 ? " / " + iTotalCount : iTotalCount;
    };

    _ServicesDeliveredTableCard.prototype._formatLinkExtended = function(bAuth, iVisibleCount, iTotalCount) {
        return (iVisibleCount > 0 && bAuth) ? " / " + iTotalCount : iTotalCount;
    };

    _ServicesDeliveredTableCard.prototype._formatDateToString = function(sDate) {
        var stringDate = sDate.replace("/Date(", "");
            stringDate = stringDate.replace(")/", "");
        var newDate = new Date();
        newDate.setTime(stringDate);
        var sYear  = (newDate.getFullYear()).toString();
        var sMonth = (newDate.getMonth()+1).toString();
        if (sMonth.length < 2){
            sMonth = "0"+ sMonth;
        }
        var sDay   = (newDate.getDate()).toString();
        var sFinalDate;
        if (sDate) {
            sFinalDate = sDay + "/" + sMonth + "/" + sYear;
        } else {
            sFinalDate = "";
        }
        return sFinalDate;
    };

    return _ServicesDeliveredTableCard;
}, /* bExport= */true);
